
import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class DisplayView extends JPanel {

	private static final long serialVersionUID = 1L;

	private JLabel ldisplay;
	GridBagConstraints c = new GridBagConstraints();

	/**
	 * Constructor for selection view that sets a frame for the UI
	 */
	public DisplayView(final String results) {

		ldisplay = new JLabel(results);

		this.setLayout(new BorderLayout());
		add(ldisplay, BorderLayout.CENTER);
		setVisible(true);
	}
}
