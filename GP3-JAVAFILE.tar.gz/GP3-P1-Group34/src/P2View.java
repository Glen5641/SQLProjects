
import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class P2View extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;

	private JButton jbop1 = new JButton("Add Problem from Author");
	private JButton jbop2 = new JButton("Raise Compensation of Specific Author");
	private JButton jbop3 = new JButton("Display Problem and Author Table");
	private JButton jbop4 = new JButton("Exit");
	private JPanel jbpanel = new JPanel(new GridBagLayout());

	GridBagConstraints c = new GridBagConstraints();

	/**
	 * Constructor for selection view that sets a frame for the UI
	 */
	public P2View() {

		setFrame();
		setButtonBorders();
		this.setLayout(new BorderLayout());
		c.anchor = GridBagConstraints.WEST;
		addComponent(jbpanel, jbop1, 0, 0, 300, 30, 180, 5, 10, 10);
		addComponent(jbpanel, jbop2, 0, 30, 300, 30, 100, 5, 10, 10);
		addComponent(jbpanel, jbop3, 0, 60, 300, 30, 130, 5, 10, 10);
		addComponent(jbpanel, jbop4, 0, 90, 300, 30, 305, 5, 10, 10);
		add(jbpanel, BorderLayout.WEST);

		setVisible(true);
	}

	public void addComponent(JComponent to, JComponent from, int gridx, int gridy, int gridwidth, int gridheight,
			int ipadx, int ipady, int weightx, int weighty) {
		c.gridx = gridx;
		c.gridy = gridy;
		c.gridwidth = gridwidth;
		c.gridheight = gridheight;
		c.ipadx = ipadx;
		c.ipady = ipady;
		c.weightx = weightx;
		c.weighty = weighty;
		to.add(from, c);
	}

	public void setButtonBorders() {
		jbop1.setBorder(BorderFactory.createRaisedBevelBorder());
		jbop2.setBorder(BorderFactory.createRaisedBevelBorder());
		jbop3.setBorder(BorderFactory.createRaisedBevelBorder());
		jbop4.setBorder(BorderFactory.createRaisedBevelBorder());
	}

	public void setFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Group Project 3");
		setLayout(new BorderLayout());
		this.setSize(345, 150);
		setLocationRelativeTo(null);
	}

	public void setActionCommands() {
		jbop1.setActionCommand("Option 1");
		jbop2.setActionCommand("Option 2");
		jbop3.setActionCommand("Option 3");
		jbop4.setActionCommand("Option 4");
	}

	public void registerJbopListener(ActionListener jbopListener) {
		jbop1.addActionListener(jbopListener);
		jbop2.addActionListener(jbopListener);
		jbop3.addActionListener(jbopListener);
		jbop4.addActionListener(jbopListener);
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {

	}
}
