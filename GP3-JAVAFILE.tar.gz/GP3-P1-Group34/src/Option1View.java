
import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Option1View extends JPanel implements ActionListener {

	private static final long serialVersionUID = 1L;

	private JLabel lpid = new JLabel("PID");
	private JLabel lpname = new JLabel("PNAME");
	private JLabel laid = new JLabel("AID");
	JTextField tpid = new JTextField();
	JTextField tpname = new JTextField();
	JComboBox<String> taid;
	JButton jbadd;
	private JPanel jbpanel = new JPanel(new GridBagLayout());
	GridBagConstraints c = new GridBagConstraints();

	/**
	 * Constructor for selection view that sets a frame for the UI
	 * 
	 * @throws SQLException
	 */
	public Option1View(final String[] results) {

		taid = new JComboBox<String>(results);

		this.setLayout(new BorderLayout());
		c.anchor = GridBagConstraints.WEST;
		addComponent(jbpanel, lpid, 0, 0, 50, 30, 50, 5, 10, 10);
		addComponent(jbpanel, lpname, 0, 30, 50, 30, 50, 5, 10, 10);
		addComponent(jbpanel, laid, 0, 60, 50, 30, 50, 5, 10, 10);
		addComponent(jbpanel, tpid, 50, 0, 50, 30, 200, 5, 10, 10);
		addComponent(jbpanel, tpname, 50, 30, 50, 30, 200, 5, 10, 10);
		addComponent(jbpanel, taid, 50, 60, 50, 30, 155, 5, 10, 10);
		jbadd = new JButton("Add");
		setButtonBorders();
		addComponent(jbpanel, jbadd, 0, 90, 100, 30, 312, 5, 10, 10);
		add(jbpanel, BorderLayout.WEST);

		setVisible(true);
	}

	public void addComponent(JComponent to, JComponent from, int gridx, int gridy, int gridwidth, int gridheight,
			int ipadx, int ipady, int weightx, int weighty) {
		c.gridx = gridx;
		c.gridy = gridy;
		c.gridwidth = gridwidth;
		c.gridheight = gridheight;
		c.ipadx = ipadx;
		c.ipady = ipady;
		c.weightx = weightx;
		c.weighty = weighty;
		to.add(from, c);
	}

	public void setButtonBorders() {
		jbadd.setBorder(BorderFactory.createRaisedBevelBorder());
	}

	public void setActionCommands() {
		jbadd.setActionCommand("Add");
	}

	public void registerJbAddListener(ActionListener jbAddListener) {
		jbadd.addActionListener(jbAddListener);
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {

	}
}
