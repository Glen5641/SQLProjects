public class problem2 {

	static private P2View view;
	static private Controller controller;

	public static void main(String[] args) {
		view = new P2View();
		controller = new Controller();
		controller.setP2View(view);
	}
}